//
//  ServiceStatus.h
//  Pods
//
//  Created by Floris Smit on 03/06/2021.
//

#ifndef ServiceStatus_h
#define ServiceStatus_h

typedef enum {
  disabled,
  enabled
} ServiceStatus;

#endif /* ServiceStatus_h */
